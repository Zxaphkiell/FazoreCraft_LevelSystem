<?php

namespace FazoreCraft\LevelSystem\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use FazoreCraft\LevelSystem\Managers\HologramManager;

class SetHologramCommand extends Command {

    public function __construct() {
        parent::__construct("setholo", "Set leaderboard hologram location", "/setholo", ["sethologram"]);
        $this->setPermission("levelsystem.admin");
    }

    public function execute(CommandSender $sender, string $label, array $args): void {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Use this command in-game.");
            return;
        }

        $pos = $sender->getPosition();
        $world = $pos->getWorld()->getFolderName();

        $config = new Config($sender->getServer()->getDataPath() . "plugins/FazoreCraft_LevelSystem/hologram.yml", Config::YAML);
        $config->setAll([
            "x" => $pos->getX(),
            "y" => $pos->getY(),
            "z" => $pos->getZ(),
            "world" => $world
        ]);
        $config->save();

        HologramManager::setLeaderboardPosition($pos);
        $sender->sendMessage("§aLeaderboard hologram position set at your current location.");
    }
}
