<?php

namespace FazoreCraft\LevelSystem\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

use FazoreCraft\LevelSystem\Forms\AdminGui;

class AdminLevelCommand extends Command {

    public function __construct() {
        parent::__construct("adminlevel", "Open admin control panel", "/adminlevel");
        $this->setPermission("levelsystem.admin");
    }

    public function execute(CommandSender $sender, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Use this command in-game.");
            return false;
        }

        if (!$sender->hasPermission("levelsystem.admin")) {
            $sender->sendMessage("§cYou do not have permission.");
            return false;
        }

        AdminGui::sendAdminPanel($sender);
        return true;
    }
}
