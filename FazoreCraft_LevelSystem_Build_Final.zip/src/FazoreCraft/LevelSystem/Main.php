<?php
namespace FazoreCraft\LevelSystem;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;

class Main extends PluginBase implements Listener {

    public function onEnable(): void {
        $this->getScheduler()->scheduleRepeatingTask(new \FazoreCraft\LevelSystem\Tasks\TitleTaskResetTask(), 20 * 60 * 180); // tiap 3 jam
        $this->getScheduler()->scheduleRepeatingTask(new \FazoreCraft\LevelSystem\Tasks\LeaderboardUpdateTask(), 20 * 300); // setiap 5 menit
        $this->getLogger()->info("FazoreCraft LevelSystem enabled!");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onDisable(): void {
        $this->getLogger()->info("FazoreCraft LevelSystem disabled.");
    }
}
