<?php

namespace FazoreCraft\LevelSystem\Managers;

use FazoreCraft\LevelSystem\Events\Game\DoubleXPEventListener;

use pocketmine\player\Player;
use FazoreCraft\LevelSystem\Utils\Logger;
use pocketmine\Server;
use pocketmine\utils\Config;
use FazoreCraft\LevelSystem\Utils\DataManager;

class XpManager {

    private static array $xpCache = [];

    public static function getXp(Player $player): int {
        return self::$xpCache[$player->getName()] ?? 0;
    }

    public static function addXp(Player $player, int $baseAmount, string $source = "unknown"): void {
        $multiplier = self::calculateXpMultiplier($player);
        $finalAmount = (int) round($baseAmount * $multiplier);

        self::$xpCache[$player->getName()] = self::getXp($player) + $finalAmount;

        DataManager::logXpChange($player, $finalAmount, $source);
        TierManager::checkLevelUp($player);
    }

    public static function calculateXpMultiplier(Player $player): float {
        $tierBonus = TierManager::getXpBonusMultiplier($player);         // ex: 1.5
        $titleBonus = TitleManager::getTitleXpBonusMultiplier($player); // ex: 2.0
        $doubleXp = self::isDoubleXpTime() ? 2.0 : 1.0;

        return $tierBonus * $titleBonus * $doubleXp;
    }

    public static function isDoubleXpTime(): bool {
        $hour = (int) date("H");
        return $hour >= 19 && $hour <= 23;
    }

    public static function sync(Player $player): void {
        $data = DataManager::readPlayerData($player);
        self::$xpCache[$player->getName()] = $data["xp"] ?? 0;
    }

    public static function save(Player $player): void {
        $data = DataManager::readPlayerData($player);
        $data["xp"] = self::getXp($player);
        DataManager::savePlayerData($player, $data);
    }
}
