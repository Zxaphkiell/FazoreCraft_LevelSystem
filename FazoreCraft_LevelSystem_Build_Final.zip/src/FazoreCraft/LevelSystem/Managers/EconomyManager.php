<?php

namespace FazoreCraft\LevelSystem\Managers;

use pocketmine\player\Player;
use pocketmine\item\ItemFactory;
use pocketmine\item\StringToItemParser;
use pocketmine\utils\Config;
use pocketmine\Server;

class EconomyManager {

    private static array $barterItems = [];

    public static function loadConfig(): void {
        $configPath = Server::getInstance()->getDataPath() . "plugins/FazoreCraft_LevelSystem/barter.yml";
        $config = new Config($configPath, Config::YAML);

        self::$barterItems = $config->getAll();
    }

    public static function getShopItems(): array {
        return self::$barterItems;
    }

    public static function levelToItemExchange(Player $player, string $itemName, int $quantity): bool {
        $data = \FazoreCraft\LevelSystem\Utils\DataManager::readPlayerData($player);
        $level = $data["level"] ?? 0;

        if (!isset(self::$barterItems[$itemName])) return false;

        $costPerItem = self::$barterItems[$itemName]["levelCost"];
        $requiredTier = self::$barterItems[$itemName]["requiredTier"] ?? "White";
        $playerTier = TierManager::getPlayerTier($player);

        $totalCost = $costPerItem * $quantity;
        if ($level < $totalCost) return false;
        if (!self::isTierAllowed($playerTier, $requiredTier)) return false;

        // kurangi level
        $data["level"] -= $totalCost;
        \FazoreCraft\LevelSystem\Utils\DataManager::savePlayerData($player, $data);

        // berikan item
        $item = StringToItemParser::getInstance()->parse($itemName);
        if ($item === null) return false;
        $item->setCount($quantity);
        $player->getInventory()->addItem($item);
        return true;
    }

    public static function isTierAllowed(string $playerTier, string $requiredTier): bool {
        $tiers = ["White", "Yellow", "Orange", "Red", "Blue", "Purple", "Black", "Rainbow"];
        return array_search($playerTier, $tiers) >= array_search($requiredTier, $tiers);
    }

    public static function addMoney(Player $player, int $amount): void {
        // Placeholder: implementasikan dengan plugin ekonomi server jika ada
        $player->sendMessage("[Economy] +$amount added to your account.");
    }
}
