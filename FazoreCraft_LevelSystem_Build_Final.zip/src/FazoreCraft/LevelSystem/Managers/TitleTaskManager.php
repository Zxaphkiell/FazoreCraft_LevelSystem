<?php

namespace FazoreCraft\LevelSystem\Managers;

use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\Server;
use FazoreCraft\LevelSystem\Utils\Logger;

class TitleTaskManager {

    private static array \$taskPool = [
        "Fighter" => [
            "Easy" => ["Kill 1 player", "Deal 100 damage", "Hit 10 targets"],
            "Medium" => ["Kill 5 players", "Win 3 PvP rounds", "Deal 500 damage"],
            "Hard" => ["Kill 10 players", "Win 5 PvP rounds", "Deal 1000 damage"]
        ],
        "Miner" => [
            "Easy" => ["Break 10 blocks", "Mine 5 ores", "Collect 20 stones"],
            "Medium" => ["Break 100 blocks", "Mine 50 ores", "Smelt 30 items"],
            "Hard" => ["Break 300 blocks", "Mine 100 ores", "Collect 64 diamonds"]
        ],
        "Farmer" => [
            "Easy" => ["Harvest 10 crops", "Plant 10 seeds", "Craft 5 bread"],
            "Medium" => ["Harvest 100 crops", "Plant 50 seeds", "Craft 50 bread"],
            "Hard" => ["Harvest 500 crops", "Craft 10 cakes", "Craft 100 bread"]
        ],
        "Builder" => [
            "Easy" => ["Place 10 blocks", "Craft 5 tools", "Build 1 structure"],
            "Medium" => ["Place 100 blocks", "Craft 50 tools", "Build 3 structures"],
            "Hard" => ["Place 500 blocks", "Craft 100 tools", "Build 5 structures"]
        ]
    ];

    public static function assignTasks(Player \$player): void {
        \$file = new Config(Server::getInstance()->getDataPath() . "plugins/FazoreCraft_LevelSystem/data/title_task.yml", Config::YAML);
        \$data = \$file->getAll();
        \$name = strtolower(\$player->getName());

        \$mainTitle = TitleManager::getMainTitle(\$player); // Ambil Main Title
        if (!in_array(\$mainTitle, array_keys(self::\$taskPool))) return;
        if (!isset(self::\$taskPool[\$mainTitle])) return;

        if (!isset(\$data[\$name]) || self::isExpired(\$data[\$name]["last_reset"] ?? 0)) {
            \$data[\$name] = [
                "title" => \$mainTitle,
                "tasks" => [
                    "easy" => self::randomTask(\$mainTitle, "Easy"),
                    "medium" => self::randomTask(\$mainTitle, "Medium"),
                    "hard" => self::randomTask(\$mainTitle, "Hard")
                ],
                "claimed" => [],
                "last_reset" => time()
            ];
            \$file->setAll(\$data);
            \$file->save();
        Logger::logAction("{$name} claimed {$difficulty} Title Task");
        }
    }

    public static function getTasks(Player \$player): array {
        \$file = new Config(Server::getInstance()->getDataPath() . "plugins/FazoreCraft_LevelSystem/data/title_task.yml", Config::YAML);
        \$data = \$file->getAll();
        return \$data[strtolower(\$player->getName())]["tasks"] ?? [];
    }

    public static function claimTask(Player \$player, string \$difficulty): bool {
        \$file = new Config(Server::getInstance()->getDataPath() . "plugins/FazoreCraft_LevelSystem/data/title_task.yml", Config::YAML);
        \$data = \$file->getAll();
        \$name = strtolower(\$player->getName());

        if (in_array(\$difficulty, \$data[\$name]["claimed"] ?? [])) return false;

        \$xpReward = match(\$difficulty) {
            "easy" => 1000,
            "medium" => 5000,
            "hard" => 10000,
            default => 0
        };
        XpManager::addXp(\$player, \$xpReward, "TitleTask");
        EconomyManager::addMoney(\$player, \$xpReward / 10);

        \$data[\$name]["claimed"][] = \$difficulty;
        \$file->setAll(\$data);
        \$file->save();
        Logger::logAction("{$name} claimed {$difficulty} Title Task");

        return true;
    }

    private static function randomTask(string \$mainTitle, string \$level): string {
        return self::\$taskPool[\$mainTitle][\$level][array_rand(self::\$taskPool[\$mainTitle][\$level])];
    }

    private static function isExpired(int \$timestamp): bool {
        \$nextReset = strtotime("+3 hours", \$timestamp);
        return time() >= \$nextReset;
    }
}
