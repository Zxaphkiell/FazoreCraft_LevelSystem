<?php

namespace FazoreCraft\LevelSystem\Managers;

use pocketmine\player\Player;
use FazoreCraft\LevelSystem\Utils\DataManager;

class RewardManager {

    private static array $rewardConfig = [
        "White" => 100,
        "Yellow" => 500,
        "Orange" => 1000,
        "Red" => 2500,
        "Blue" => 5000,
        "Purple" => 10000,
        "Black" => 25000,
        "Rainbow" => 50000
    ];

    public static function giveLevelReward(Player $player, int $level): void {
        $data = DataManager::readPlayerData($player);
        if (!isset($data["levelRewarded"])) {
            $data["levelRewarded"] = [];
        }

        if (!in_array($level, $data["levelRewarded"])) {
            $money = self::calculateLevelReward($level);
            EconomyManager::addMoney($player, $money);
            $data["levelRewarded"][] = $level;
            DataManager::savePlayerData($player, $data);
        }
    }

    public static function giveTierReward(Player $player, string $tier): void {
        $data = DataManager::readPlayerData($player);
        if (!isset($data["tierRewarded"])) {
            $data["tierRewarded"] = [];
        }

        if (!in_array($tier, $data["tierRewarded"])) {
            $money = self::$rewardConfig[$tier] ?? 0;
            EconomyManager::addMoney($player, $money * 2); // reward x2 untuk pertama masuk tier
            $data["tierRewarded"][] = $tier;
            DataManager::savePlayerData($player, $data);
        }
    }

    private static function calculateLevelReward(int $level): int {
        if ($level < 10) return 100;
        if ($level < 50) return 200;
        if ($level < 100) return 300;
        if ($level < 1000) return 500;
        if ($level < 10000) return 1000;
        return 1500;
    }
}
