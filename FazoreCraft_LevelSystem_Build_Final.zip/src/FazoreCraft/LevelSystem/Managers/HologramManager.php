<?php

namespace FazoreCraft\LevelSystem\Managers;

use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\Position;
use DaPigGuy\libPiggyUpdateChecker\libs\CortexPE\Commando\args\RawStringArgument;
use DaPigGuy\libPiggyUpdateChecker\libs\CortexPE\Commando\BaseCommand;
use pocketmine\player\Player;
use pocketmine\utils\TextFormat as TF;

class HologramManager {

    private static ?Position $leaderboardPos = null;

    public static function setLeaderboardPosition(Position $pos): void {
        self::$leaderboardPos = $pos;
        self::updateLeaderboardHologram();
    }

    public static function updateLeaderboardHologram(): void {
        if (self::$leaderboardPos === null) return;

        $top = DataManager::readLeaderboard();
        $world = self::$leaderboardPos->getWorld();

        $yOffset = 0.3;
        $i = 1;
        foreach ($top as $name => $info) {
            $color = "§f";
            if ($i === 1) $color = "§6§l"; // bold gold
            elseif ($i <= 3) $color = "§e§l"; // bold yellow
            elseif ($i <= 10) $color = "§b"; // light blue

            $tier = TierManager::getPlayerTierByName($name);
            if ($tier === "Rainbow") {
                $tierColor = "§c§6§e§a§b§d§f";
            } else {
                $tierColor = "§7";
            }

            $text = "{$color}#{$i} §r§f{$name} - {$tierColor}{$tier} §7({$info["xp"]} XP)";
            $position = self::$leaderboardPos->add(0, $i * $yOffset, 0);
            self::spawnFloatingText($position, $text);
            $i++;
        }
    }

    private static function spawnFloatingText(Vector3 $pos, string $text): void {
        // Placeholder only. Integrate with actual hologram plugin like FloatingTextParticles or HologramAPI
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            $player->sendPopup($text); // debug fallback
        }
    }
}
