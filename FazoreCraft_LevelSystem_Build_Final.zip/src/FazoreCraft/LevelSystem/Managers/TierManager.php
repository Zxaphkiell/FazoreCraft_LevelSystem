<?php

namespace FazoreCraft\LevelSystem\Managers;

use pocketmine\player\Player;
use FazoreCraft\LevelSystem\Utils\DataManager;

class TierManager {

    private const TIERS = [
        "White" => 0,
        "Yellow" => 10,
        "Orange" => 50,
        "Red" => 100,
        "Blue" => 1000,
        "Purple" => 10000,
        "Black" => 50000,
        "Rainbow" => 100000
    ];

    private const TIER_EFFECTS = [
        "Purple" => ["speed" => 1],
        "Black" => ["speed" => 2, "strength" => 1],
        "Rainbow" => ["speed" => 2, "strength" => 2, "saturation" => 1, "regeneration" => 1]
    ];

    private const XP_BONUS = [
        "White" => 0.5,
        "Yellow" => 1.0,
        "Orange" => 1.5,
        "Red" => 2.0,
        "Blue" => 2.5,
        "Purple" => 3.0,
        "Black" => 4.0,
        "Rainbow" => 5.0
    ];

    public static function getPlayerLevel(Player $player): int {
        $data = DataManager::readPlayerData($player);
        return $data["level"] ?? 0;
    }

    public static function getPlayerTier(Player $player): string {
        $data = DataManager::readPlayerData($player);
        return $data["tier"] ?? "White";
    }

    public static function checkLevelUp(Player $player): void {
        $xp = XpManager::getXp($player);
        $level = floor($xp / 500); // Sementara: 500 XP = 1 Level
        $data = DataManager::readPlayerData($player);
        if (($data["level"] ?? 0) !== $level) {
            $data["level"] = $level;
            $data["tier"] = self::calculateTier($level);
            DataManager::savePlayerData($player, $data);
        }
    }

    public static function calculateTier(int $level): string {
        $tier = "White";
        foreach (self::TIERS as $name => $requiredLevel) {
            if ($level >= $requiredLevel) {
                $tier = $name;
            }
        }
        return $tier;
    }

    public static function getXpBonusMultiplier(Player $player): float {
        $tier = self::getPlayerTier($player);
        return self::XP_BONUS[$tier] ?? 1.0;
    }
}
