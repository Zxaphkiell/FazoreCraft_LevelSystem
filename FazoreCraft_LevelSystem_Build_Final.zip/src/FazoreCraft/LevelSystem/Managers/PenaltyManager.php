<?php

namespace FazoreCraft\LevelSystem\Managers;

use pocketmine\player\Player;
use pocketmine\Server;
use DateTime;
use DateInterval;
use FazoreCraft\LevelSystem\Utils\DataManager;

class PenaltyManager {

    private static array $penaltyRate = [
        1 => 0.25,  // 1 minggu tidak login = -25% XP
        2 => 0.50,
        3 => 0.75,
        4 => 1.00   // reset total XP jika 4 minggu tidak login
    ];

    public static function checkInactivityPenalty(): void {
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            self::updateLastLogin($player);
        }

        $all = DataManager::readLastLoginData();
        $now = new DateTime();

        foreach ($all as $playerName => $info) {
            $lastLogin = new DateTime($info["lastLogin"] ?? "1970-01-01 00:00:00");
            $weeks = floor($now->diff($lastLogin)->days / 7);

            if ($weeks >= 1 && $weeks <= 4) {
                $penaltyRate = self::$penaltyRate[$weeks] ?? 0;
                $player = Server::getInstance()->getPlayerExact($playerName);

                $xp = XpManager::getXpByName($playerName);
                $penaltyXp = (int) round($xp * $penaltyRate);
                XpManager::setXpByName($playerName, $xp - $penaltyXp);

                DataManager::logAction("Penalty applied to $playerName: -$penaltyXp XP ($penaltyRate)");

                if ($player !== null) {
                    $player->sendMessage("You received a penalty of $penaltyXp XP for not logging in $weeks week(s).");
                }
            }
        }
    }

    public static function updateLastLogin(Player $player): void {
        $all = DataManager::readLastLoginData();
        $all[$player->getName()] = [
            "lastLogin" => date("Y-m-d H:i:s")
        ];
        DataManager::saveLastLoginData($all);
    }
}
