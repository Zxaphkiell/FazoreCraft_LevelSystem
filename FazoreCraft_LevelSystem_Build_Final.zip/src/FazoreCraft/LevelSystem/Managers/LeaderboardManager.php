<?php

namespace FazoreCraft\LevelSystem\Managers;

use pocketmine\player\Player;
use pocketmine\Server;
use FazoreCraft\LevelSystem\Utils\DataManager;

class LeaderboardManager {

    private const TOP_COUNT = 10;

    public static function updateLeaderboard(): void {
        $all = DataManager::readAllPlayerData();
        $ranking = [];

        foreach ($all as $name => $data) {
            $xp = $data["xp"] ?? 0;
            $timestamp = $data["xpUpdatedAt"] ?? time();
            $ranking[$name] = ["xp" => $xp, "timestamp" => $timestamp];
        }

        uasort($ranking, function($a, $b) {
            if ($a["xp"] === $b["xp"]) {
                return $a["timestamp"] <=> $b["timestamp"];
            }
            return $b["xp"] <=> $a["xp"];
        });

        $top = array_slice($ranking, 0, self::TOP_COUNT, true);
        DataManager::saveLeaderboard($top);

        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            self::applyLeaderboardEffect($player);
        }
    }

    public static function applyLeaderboardEffect(Player $player): void {
        $top = DataManager::readLeaderboard();
        $rank = self::getPlayerRank($player);

        if ($rank !== null && $rank <= 10) {
            // Beri efek Haste 3
            $player->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(
                \pocketmine\entity\effect\VanillaEffects::HASTE(), 999999, 2, false
            ));
        } else {
            // Hapus efek
            $player->getEffects()->remove(\pocketmine\entity\effect\VanillaEffects::HASTE());
        }
    }

    public static function getPlayerRank(Player $player): ?int {
        $top = DataManager::readLeaderboard();
        $i = 1;
        foreach ($top as $name => $info) {
            if (strtolower($name) === strtolower($player->getName())) {
                return $i;
            }
            $i++;
        }
        return null;
    }

    public static function resetLeaderboard(): void {
        DataManager::saveLeaderboard([]);
    }
}
