<?php

namespace FazoreCraft\LevelSystem\Managers;

use pocketmine\player\Player;
use FazoreCraft\LevelSystem\Utils\DataManager;

class TitleManager {

    private static array $mainTitles = ["Fighter", "Miner", "Farmer", "Builder"];

    public static function getMainTitle(Player $player): ?string {
        $data = DataManager::readPlayerData($player);
        return $data["mainTitle"] ?? null;
    }

    public static function setMainTitle(Player $player, string $title): bool {
        if (!in_array($title, self::$mainTitles)) return false;

        $data = DataManager::readPlayerData($player);
        if (!isset($data["titleChangeHistory"])) {
            $data["titleChangeHistory"] = [];
        }

        $tier = TierManager::getPlayerTier($player);
        if (in_array($tier, $data["titleChangeHistory"] ?? [])) return false;

        $data["mainTitle"] = $title;
        $data["titleChangeHistory"][] = $tier;
        DataManager::savePlayerData($player, $data);
        return true;
    }

    public static function getEnchantedTitles(Player $player): array {
        $data = DataManager::readTitleData($player);
        return $data["enchanted"] ?? [];
    }

    public static function addEnchantedTitle(Player $player, string $title): void {
        $data = DataManager::readTitleData($player);
        if (!in_array($title, $data["enchanted"] ?? [])) {
            $data["enchanted"][] = $title;
            DataManager::saveTitleData($player, $data);
        }
    }

    public static function getTitleXpBonusMultiplier(Player $player): float {
        $main = self::getMainTitle($player);
        if (!$main) return 1.0;

        $activity = ActivityManager::getPlayerActivityType($player); // ex: mining, building
        if (strtolower($activity) === strtolower($main)) {
            $enchanted = self::getCurrentTitle($player);
            return in_array($enchanted, self::getEnchantedTitles($player)) ? 2.0 : 1.5;
        }
        return 1.0;
    }

    public static function getCurrentTitle(Player $player): ?string {
        $data = DataManager::readPlayerData($player);
        return $data["currentTitle"] ?? null;
    }

    public static function setCurrentTitle(Player $player, string $title): void {
        $data = DataManager::readPlayerData($player);
        $data["currentTitle"] = $title;
        DataManager::savePlayerData($player, $data);
    }
}
