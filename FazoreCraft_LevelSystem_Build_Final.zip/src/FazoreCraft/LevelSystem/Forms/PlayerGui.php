<?php

namespace FazoreCraft\LevelSystem\Forms;

use pocketmine\player\Player;
use Vecnavium\FormsUI\SimpleForm;
use FazoreCraft\LevelSystem\Managers\TitleTaskManager;

class PlayerGui {

    public static function sendMainGui(Player $player): void {
        $form = new SimpleForm(function (Player $player, ?int $data): void {
            if ($data === null) return;

            switch ($data) {
                case 0:
                    self::sendTaskGui($player);
                    break;
                case 1:
                    $player->sendMessage("XP Menu Coming Soon...");
                    break;
            }
        });

        $form->setTitle("§l§aFazoreCraft §fMenu");
        $form->addButton("§bTitle Task");
        $form->addButton("§7XP Info");
        $player->sendForm($form);
    }

    public static function sendTaskGui(Player $player): void {
        $mainTitle = \FazoreCraft\LevelSystem\Managers\TitleManager::getMainTitle($player);
        if (!$mainTitle || !in_array($mainTitle, ["Fighter", "Miner", "Farmer", "Builder"])) {
            $player->sendMessage("§cYou must choose a Main Title to access Title Tasks!");
            return;
        }

        TitleTaskManager::assignTasks($player);
        $tasks = TitleTaskManager::getTasks($player);

        $form = new SimpleForm(function (Player $player, ?int $data): void {
            if ($data === null) return;

            $difficulty = match ($data) {
                0 => "easy",
                1 => "medium",
                2 => "hard",
                default => null
            };

            if ($difficulty && TitleTaskManager::claimTask($player, $difficulty)) {
                $player->sendMessage("§aYou have claimed your {$difficulty} task reward!");
            } else {
                $player->sendMessage("§cYou already claimed this reward or something went wrong.");
            }
        });

        $form->setTitle("§l§6Title Tasks");
        $form->addButton("§a[Easy] §r" . $tasks["easy"]);
        $form->addButton("§e[Medium] §r" . $tasks["medium"]);
        $form->addButton("§c[Hard] §r" . $tasks["hard"]);
        $player->sendForm($form);
    }
}
