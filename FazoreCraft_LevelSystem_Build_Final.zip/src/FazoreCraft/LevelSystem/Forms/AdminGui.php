<?php

namespace FazoreCraft\LevelSystem\Forms;

use pocketmine\player\Player;
use Vecnavium\FormsUI\SimpleForm;
use pocketmine\Server;

use FazoreCraft\LevelSystem\Managers\XpManager;
use FazoreCraft\LevelSystem\Managers\TierManager;
use FazoreCraft\LevelSystem\Managers\TitleManager;
use FazoreCraft\LevelSystem\Managers\TitleTaskManager;

class AdminGui {

    public static function sendAdminPanel(Player $admin): void {
        $form = new SimpleForm(function (Player $admin, ?int $data): void {
            if ($data === null) return;

            switch ($data) {
                case 0:
                    self::sendSelectPlayerGui($admin);
                    break;
                case 1:
                    self::sendGlobalControlGui($admin);
                    break;
            }
        });

        $form->setTitle("§l§cAdmin Panel");
        $form->addButton("§aManage Player");
        $form->addButton("§6Server Control");
        $admin->sendForm($form);
    }

    public static function sendSelectPlayerGui(Player $admin): void {
        $form = new SimpleForm(function (Player $admin, ?int $data) use (&$form): void {
            if ($data === null) return;

            $players = array_values(Server::getInstance()->getOnlinePlayers());
            if (!isset($players[$data])) return;

            $target = $players[$data];
            self::sendPlayerManageGui($admin, $target);
        });

        $form->setTitle("§l§aSelect Player");
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            $form->addButton($p->getName());
        }
        $admin->sendForm($form);
    }

    public static function sendPlayerManageGui(Player $admin, Player $target): void {
        $xp = XpManager::getXp($target);
        $level = XpManager::getLevel($target);
        $tier = TierManager::getTierName($target);
        $title = TitleManager::getMainTitle($target) ?? "None";

        $form = new SimpleForm(function (Player $admin, ?int $data) use ($target): void {
            if ($data === null) return;

            switch ($data) {
                case 0:
                    XpManager::addXp($target, 5000, "AdminBoost");
                    $admin->sendMessage("§a+5000 XP added to " . $target->getName());
                    break;
                case 1:
                    TitleManager::resetTitle($target);
                    $admin->sendMessage("§cTitle reset for " . $target->getName());
                    break;
                case 2:
                    TitleTaskManager::assignTasks($target);
                    $admin->sendMessage("§eTasks reset for " . $target->getName());
                    break;
            }
        });

        $form->setTitle("§l§bPlayer: " . $target->getName());
        $form->setContent("§7XP: §f{$xp}\n§7Level: §f{$level}\n§7Tier: §f{$tier}\n§7Title: §f{$title}");
        $form->addButton("§a+5000 XP");
        $form->addButton("§cReset Title");
        $form->addButton("§eReset Title Task");
        $admin->sendForm($form);
    }

    public static function sendGlobalControlGui(Player $admin): void {
        $form = new SimpleForm(function (Player $admin, ?int $data): void {
            if ($data === null) return;

            switch ($data) {
                case 0:
                    $admin->sendMessage("§b[!] Simulated XP Event Triggered");
                    break;
            }
        });

        $form->setTitle("§l§6Global Control");
        $form->addButton("Trigger XP Event (Simulated)");
        $admin->sendForm($form);
    }
}
