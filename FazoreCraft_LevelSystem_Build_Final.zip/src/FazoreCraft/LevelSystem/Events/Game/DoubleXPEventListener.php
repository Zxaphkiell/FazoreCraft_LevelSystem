<?php

namespace FazoreCraft\LevelSystem\Events\Game;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\Server;
use pocketmine\utils\Config;

class DoubleXPEventListener implements Listener {

    public static bool \$isDoubleXpActive = false;

    public function onPlayerJoin(PlayerJoinEvent \$event): void {
        if (self::checkTimeWindow()) {
            \$event->getPlayer()->sendMessage("§b[Event] Double XP is active from 19:00 to 23:59 today!");
        }
    }

    public static function checkTimeWindow(): bool {
        \$config = new Config(Server::getInstance()->getDataPath() . "plugins/FazoreCraft_LevelSystem/config.yml", Config::YAML);
        if (!\$config->getNested("doubleXp.enabled")) return false;

        \$start = \$config->getNested("doubleXp.time.start", "19:00");
        \$end = \$config->getNested("doubleXp.time.end", "23:59");

        \$now = strtotime(date("H:i"));
        \$startTime = strtotime(\$start);
        \$endTime = strtotime(\$end);

        self::\$isDoubleXpActive = (\$now >= \$startTime && \$now <= \$endTime);
        return self::\$isDoubleXpActive;
    }

    public static function isDoubleXp(): bool {
        return self::\$isDoubleXpActive;
    }
}
