<?php

namespace FazoreCraft\LevelSystem\Utils;

use pocketmine\Server;

class Logger {

    private static function getLogPath(string $file): string {
        return Server::getInstance()->getDataPath() . "plugins/FazoreCraft_LevelSystem/data/logs/" . $file;
    }

    public static function logAction(string $text): void {
        $msg = "[" . date("Y-m-d H:i:s") . "] " . $text . "\n";
        file_put_contents(self::getLogPath("actions.log"), $msg, FILE_APPEND);
    }

    public static function logXp(string $player, int $amount, string $source): void {
        $msg = "[" . date("Y-m-d H:i:s") . "] {$player} gained {$amount} XP from {$source}\n";
        file_put_contents(self::getLogPath("xp_changes.log"), $msg, FILE_APPEND);
    }

    public static function logError(string $text): void {
        $msg = "[" . date("Y-m-d H:i:s") . "] [ERROR] " . $text . "\n";
        file_put_contents(self::getLogPath("error.log"), $msg, FILE_APPEND);
    }
}
