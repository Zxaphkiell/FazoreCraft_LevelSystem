<?php

namespace FazoreCraft\LevelSystem\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\utils\Config;
use FazoreCraft\LevelSystem\Managers\TitleTaskManager;
use pocketmine\player\Player;

class TitleTaskResetTask extends Task {

    public function onRun(): void {
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            TitleTaskManager::assignTasks($player);
        }
    }
}
