<?php

namespace FazoreCraft\LevelSystem\Tasks;

use pocketmine\scheduler\Task;
use FazoreCraft\LevelSystem\Managers\LeaderboardManager;
use FazoreCraft\LevelSystem\Managers\HologramManager;

class LeaderboardUpdateTask extends Task {

    public function onRun(): void {
        LeaderboardManager::updateLeaderboard();
        HologramManager::updateLeaderboardHologram();
    }
}
