# FazoreCraft_LevelSystem

Custom leveling and title plugin for FazoreCraft server.